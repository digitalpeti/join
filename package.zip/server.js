import express from "express";
import bodyParser from "body-parser";
import cors from "cors";
import dotenv from "dotenv";
// Import Lambda handlers (converted to local-callable functions)
import { handler as uploadProfile } from "./ragService/handlers/uploadProfile.js";
import { handler as searchProfiles } from "./ragService/handlers/searchProfiles.js";
import { handler as autoMatch } from "./ragService/handlers/autoMatch.js";
dotenv.config();

const app = express();
app.use(bodyParser.json());
app.use(cors());

// Wrapper utility to call Lambda-style handlers locally
const runLambda = async (lambdaHandler, req, res) => {
    try {
        const event = {
            body: JSON.stringify(req.body),
            queryStringParameters: req.query,
            headers: req.headers,
        };

        const result = await lambdaHandler(event);

        res.status(result.statusCode || 200).send(result.body);
    } catch (err) {
        console.error("ERROR:", err);
        res.status(500).send({ error: err.message });
    }
};

// -----------------------------
//       API ENDPOINTS
// -----------------------------

// Upload / Index profile
app.post("/profile/upload", async (req, res) => {
    await runLambda(uploadProfile, req, res);
});

// Semantic search
app.post("/profile/search", async (req, res) => {
    await runLambda(searchProfiles, req, res);
});

// Auto match (AI matchmaking)
app.post("/profile/automatch", async (req, res) => {
    await runLambda(autoMatch, req, res);
});

// Health check
app.get("/", (req, res) => {
    res.send("Matchmaking API is running locally 🚀");
});

// -----------------------------
//       START SERVER
// -----------------------------

const PORT = process.env.PORT || 5000;
app.listen(PORT, () => {
    console.log(`🚀 Server running on http://localhost:${PORT}`);
});
