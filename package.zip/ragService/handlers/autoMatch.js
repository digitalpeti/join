import AWS from "aws-sdk";
import { embedProfileText } from "../services/embedUtils.js";
import { maleIndex, femaleIndex } from "../services/pineconeClient.js";
import { computeMetadataScore, calculateMatchScore } from "../services/matchScoring.js";

const s3 = new AWS.S3();

export const handler = async (event) => {
    const { userId, gender } = JSON.parse(event.body);

    // 1. Load user profile from S3
    const userRaw = await s3.getObject({
        Bucket: process.env.AWS_S3_BUCKET,
        Key: `profiles/${userId}.json`
    }).promise();

    const user = JSON.parse(userRaw.Body.toString());

    // 2. Embed the user
    const userEmbedding = await embedProfileText(user);

    // 3. Choose opposite gender index
    const targetIndex = user.gender === "male" ? femaleIndex : maleIndex;

    // 4. Query Pinecone
    const results = await targetIndex.query({
        vector: userEmbedding,
        topK: 20,
        includeMetadata: true
    });

    // 5. Score matches
    const scored = results.matches.map(match => {
        const metadataScore = computeMetadataScore(user, match.metadata);
        const finalScore = calculateMatchScore(match.score, metadataScore);
        return {
            ...match,
            finalScore
        };
    });

    // 6. Sort by final score
    scored.sort((a, b) => b.finalScore - a.finalScore);

    return {
        statusCode: 200,
        body: JSON.stringify(scored.slice(0, 10)) // top 10 matches
    };
};
