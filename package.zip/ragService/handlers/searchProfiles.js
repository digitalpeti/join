import { maleIndex, femaleIndex } from "../services/pineconeClient.js";
import { getEmbedding, getFinalResponse } from "../services/embedUtilsG.js";

export const handler = async (event) => {
    const body = JSON.parse(event.body);

    const gender = body.gender.toLowerCase(); // search target
    const query = body.query;
    const filter = body.filter || {};

    const targetIndex = gender === "male" ? maleIndex : femaleIndex;

    // 1. Convert query → embedding
    const vector = await getEmbedding(query);

    // 2. Query Pinecone
    const results = await targetIndex.query({
        vector,
        topK: 20,
        includeMetadata: true,
        filter
    });

    const clean = results.matches.map(r => ({
        id: r.id,
        score: r.score,
        metadata: r.metadata
    }));

    const finalResult = await getFinalResponse(query, clean);

    return {
        statusCode: 200,
        body: finalResult
    };
};
