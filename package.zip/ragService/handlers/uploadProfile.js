import { maleIndex, femaleIndex } from "../services/pineconeClient.js";
import { getEmbedding } from "../services/embedUtilsG.js";

export const handler = async (event) => {
    console.log("event", event);
    const body = JSON.parse(event.body);
    const gender = body.gender.toLowerCase();
    const profileId = body.profileId;

    // 2. Create embedding
    const vector = await getEmbedding(JSON.stringify(body));
    console.log("vector", vector);
    // 3. Choose index
    const targetIndex = gender === "male" ? maleIndex : femaleIndex;

    // 4. Upsert into Pinecone
    await targetIndex.upsert([
        {
            id: profileId,
            values: vector,
            metadata: {
                age: body.age,
                gender: gender,
                religion: body.religion,
                education: body.education,
                profession: body.profession,
                location: body.location,
                lifestyle: body.lifestyle || []
            }
        }
    ]);

    return {
        statusCode: 200,
        body: JSON.stringify({ message: "Profile uploaded & indexed" })
    };
};
