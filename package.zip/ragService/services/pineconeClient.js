import { Pinecone } from '@pinecone-database/pinecone';

const pinecone = new Pinecone({
    apiKey: process.env.PINECONE_API_KEY || "pcsk_22Gar2_HisSHqLGG6HzaoXNLm8c6PtCbdQYqSGXD4XTHZ8pnut4Hztb1oQDMAgoNTAYjd1"
});

export const maleIndex = pinecone.index(process.env.PINECONE_MALE_INDEX || "jain1-male-index");
export const femaleIndex = pinecone.index(process.env.PINECONE_FEMALE_INDEX || "jain1-female-index");
