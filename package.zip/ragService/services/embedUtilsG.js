import { GoogleGenerativeAI } from "@google/generative-ai";

const genAI = new GoogleGenerativeAI(process.env.GEMINI_API_KEY || "AIzaSyDKj8X_TSeitrjD16N8QbP39FeU6tHQKy8");

export async function getEmbedding(text) {
    try {
        const model = genAI.getGenerativeModel({ model: "text-embedding-004" });

        const result = await model.embedContent(text);
        console.log("result", result);
        return result.embedding.values; // returns float vector array
    } catch (err) {
        console.error("Embedding Error:", err);
        throw err;
    }
}

export async function getFinalResponse(userQuery, matches) {
    try {
        const chatModel = genAI.getGenerativeModel({ model: "models/gemini-2.5-pro" });
        const prompt = `User Query: "${userQuery}" Top Matching Profiles from Vector DB:\ ${JSON.stringify(matches, null, 2)} Task:
                      - Understand the user query
                     - Analyze the matching profiles
- Produce a clear, helpful response for the customer
- Summaries should be accurate and based only on metadata
`;
        const aiResponse = await chatModel.generateContent(prompt);
        const answer = aiResponse.response.text();
        console.log("result", answer);
        return answer; // returns float vector array
    } catch (err) {
        console.error("Embedding Error:", err);
        throw err;
    }
}
