import OpenAI from "openai";

export const openai = new OpenAI({
    apiKey: process.env.OPENAI_API_KEY || "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"
});
