import { openai } from "./openaiClient.js";

export const embedProfileText = async (profile) => {
    const text = `
    Name: ${profile.name}
    Gender: ${profile.gender}
    Age: ${profile.age}
    Religion: ${profile.religion}
    Profession: ${profile.profession}
    Education: ${profile.education}
    Location: ${profile.location}
    Preferences: ${JSON.stringify(profile.preferences)}
  `;

    const embeddingRes = await openai.embeddings.create({
        model: "text-embedding-3-large",
        input: text
    });

    return embeddingRes.data[0].embedding;
};

export const embedQueryText = async (query) => {
    const embeddingRes = await openai.embeddings.create({
        model: "text-embedding-3-large",
        input: query
    });

    return embeddingRes.data[0].embedding;
};
