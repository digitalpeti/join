export const calculateMatchScore = (semanticScore, metadataScore) => {
    return (semanticScore * 0.7) + (metadataScore * 0.3);
};

export const computeMetadataScore = (user, candidate) => {
    let score = 0;

    // Age compatibility
    if (candidate.age >= user.preferences.partnerAgeRange[0] &&
        candidate.age <= user.preferences.partnerAgeRange[1]) {
        score += 40;
    }

    // Location preference
    if (user.preferences.partnerLocation === candidate.location) {
        score += 30;
    }

    // Lifestyle match
    if (candidate.lifestyle && user.preferences.lifestyle) {
        const common = candidate.lifestyle.filter(v => user.preferences.lifestyle.includes(v));
        score += Math.min(30, common.length * 10);
    }

    return score / 100;
};
