import React from 'react'
import PaymentButton from './components/PaymentButton'


export default function App() {
    return (
        <div className="min-h-screen flex items-center justify-center bg-slate-50 p-6">
            <div className="w-full max-w-md bg-white rounded-2xl shadow-md p-6">
                <h1 className="text-2xl font-semibold mb-4">Pay with UPI (Razorpay)</h1>
                <p className="text-sm text-slate-600 mb-6">This demo opens Razorpay Checkout with UPI-only options.</p>
                <PaymentButton />
            </div>
        </div>
    )
}