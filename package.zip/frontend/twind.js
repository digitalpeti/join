import { setup } from 'twind';
import * as colors from 'twind/colors';


setup({
    theme: {
        extend: {
            colors
        }
    }
});